package rpgboss.editor.misc

import rpgboss.model.resource.RpgMap

trait SelectsMap {
  def selectMap(mOpt: Option[RpgMap])
}


